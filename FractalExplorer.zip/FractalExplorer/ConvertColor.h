#ifndef CONVERTCOLOR_H
#define CONVERTCOLOR_H
#include <iostream>
#include <cstdlib>
#include <cmath>


class ConvertColor
{
public:
    static void RGBtoHSV(float& fR, float& fG, float fB, float& fH, float& fS, float& fV);
    static void HSVtoRGB(float& fR, float& fG, float& fB, float& fH, float& fS, float& fV);
};
#endif
